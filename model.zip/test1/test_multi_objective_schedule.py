import csv
import io
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from test1 import (
    ASGAT_GNN,
    Satellite,
    Task,
    build_gnn_guided_key_vectors,
    calculate_energy_available_sum,
    evaluate_assignment,
    format_schedule_methods_summary,
    load_or_pretrain_gnn_for_nsga_de,
    run_profit_first_nsga_de,
    multi_objective_schedule,
    select_lexicographic_best_assignment,
    select_best_schedule_method,
    sort_schedule_methods,
)


def make_satellite(sat_id, supported_task_types, windows=10, energy=1000.0, status="服务中"):
    return Satellite(
        sat_id=sat_id,
        model="test",
        energy_available_Wh=energy,
        status=status,
        orbit_height_m=500000.0,
        inclination_deg=45.0,
        eccentricity=0.0,
        semi_major_axis=7000000.0,
        raan=0.0,
        arg_of_perigee=0.0,
        windows_today=windows,
        completed_tasks=[],
        pending_tasks=[],
        utilization=0.0,
        supported_task_types=supported_task_types,
    )


def make_task(task_id, profit, start, end, task_type="default", energy=10.0):
    return Task(
        task_id=task_id,
        priority=1,
        start_time=start,
        end_time=end,
        profit=profit,
        energy=energy,
        task_type=task_type,
        status="调度中",
    )


class LexicographicScheduleTests(unittest.TestCase):
    def test_profit_has_priority_over_task_count(self):
        tasks = [
            make_task("high", 100.0, 0, 10, "high"),
            make_task("low_1", 40.0, 0, 5, "low"),
            make_task("low_2", 40.0, 5, 10, "low"),
        ]
        satellites = [
            make_satellite("S0", ["high", "low"]),
            make_satellite("S1", ["none"]),
        ]

        best_assignment, best_profit, best_task_count = select_lexicographic_best_assignment(
            [
                [0, 0, 0],  # profit 100, one accepted task
                [1, 0, 0],  # profit 80, two accepted tasks
            ],
            tasks,
            satellites,
        )

        self.assertEqual(best_assignment.tolist(), [0, 0, 0])
        self.assertEqual(best_profit, 100.0)
        self.assertEqual(best_task_count, 1)

    def test_task_count_breaks_equal_profit_ties(self):
        tasks = [
            make_task("single", 100.0, 0, 10, "single"),
            make_task("part_1", 50.0, 0, 5, "part"),
            make_task("part_2", 50.0, 5, 10, "part"),
        ]
        satellites = [
            make_satellite("S0", ["single", "part"]),
            make_satellite("S1", ["none"]),
        ]

        best_assignment, best_profit, best_task_count = select_lexicographic_best_assignment(
            [
                [0, 0, 0],  # profit 100, one accepted task
                [1, 0, 0],  # profit 100, two accepted tasks
            ],
            tasks,
            satellites,
        )

        self.assertEqual(best_assignment.tolist(), [1, 0, 0])
        self.assertEqual(best_profit, 100.0)
        self.assertEqual(best_task_count, 2)

    def test_remaining_energy_breaks_profit_and_task_count_ties(self):
        tasks = [
            make_task("efficient", 100.0, 0, 10, "default", energy=10.0),
            make_task("expensive", 100.0, 0, 10, "default", energy=30.0),
        ]
        satellites = [make_satellite("S0", ["default"], windows=1, energy=100.0)]

        best_assignment, best_profit, best_task_count = select_lexicographic_best_assignment(
            [
                [0, -1],  # profit 100, one task, remaining energy 90
                [-1, 0],  # profit 100, one task, remaining energy 70
            ],
            tasks,
            satellites,
        )

        self.assertEqual(best_assignment.tolist(), [0, -1])
        self.assertEqual(best_profit, 100.0)
        self.assertEqual(best_task_count, 1)

    def test_invalid_or_empty_assignments_are_robust(self):
        tasks = [make_task("task", 10.0, 0, 1)]
        satellites = [make_satellite("S0", ["default"])]

        profit, task_count, accepted = evaluate_assignment(tasks, satellites, [99])
        self.assertEqual(profit, 0.0)
        self.assertEqual(task_count, 0)
        self.assertEqual(accepted, [])

        best_assignment, best_profit, best_task_count = select_lexicographic_best_assignment(
            [],
            tasks,
            satellites,
        )
        self.assertEqual(best_assignment.tolist(), [])
        self.assertEqual(best_profit, 0.0)
        self.assertEqual(best_task_count, 0)

    def test_multi_objective_schedule_applies_lexicographic_choice(self):
        rows = [
            {
                "task_id": "single",
                "priority": "1",
                "start_time": "0",
                "end_time": "10",
                "profit": "100",
                "energy": "10",
                "task_type": "single",
                "status": "调度中",
            },
            {
                "task_id": "part_1",
                "priority": "1",
                "start_time": "0",
                "end_time": "5",
                "profit": "50",
                "energy": "10",
                "task_type": "part",
                "status": "调度中",
            },
            {
                "task_id": "part_2",
                "priority": "1",
                "start_time": "5",
                "end_time": "10",
                "profit": "50",
                "energy": "10",
                "task_type": "part",
                "status": "调度中",
            },
        ]

        with tempfile.TemporaryDirectory() as temp_dir:
            tasks_path = Path(temp_dir) / "tasks.csv"
            with tasks_path.open("w", newline="", encoding="utf-8-sig") as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=list(rows[0].keys()))
                writer.writeheader()
                writer.writerows(rows)

            satellites = {
                "S0": make_satellite("S0", ["single", "part"]),
                "S1": make_satellite("S1", ["none"]),
            }
            log_file = io.StringIO()
            multi_objective_schedule(
                str(tasks_path),
                satellites,
                log_file,
                gnn_model=None,
                pop_size=12,
                n_gen=0,
                seed=7,
            )

        self.assertEqual([task.task_id for task in satellites["S0"].pending_tasks], ["part_1", "part_2"])
        self.assertEqual(satellites["S0"].total_profit, 100.0)
        self.assertEqual(satellites["S0"].total_task_number, 2)
        self.assertIn("NSGA-DE 收益优先调度: total_profit=100.00, total_task_number=2", log_file.getvalue())

    def test_profit_first_nsga_de_seed_beats_priority_greedy_pattern(self):
        tasks = [
            make_task("priority_long", 100.0, 0, 10, "default"),
            make_task("short_a", 70.0, 0, 5, "default"),
            make_task("short_b", 70.0, 5, 10, "default"),
        ]
        tasks[0].priority = 10
        tasks[1].priority = 1
        tasks[2].priority = 1
        satellites = [make_satellite("S0", ["default"], windows=2)]

        result = run_profit_first_nsga_de(
            tasks,
            satellites,
            pop_size=12,
            n_gen=0,
            seed=7,
        )

        self.assertEqual(result["total_profit"], 140.0)
        self.assertEqual(result["total_task_number"], 2)
        self.assertEqual(result["energy_available_Wh_sum"], 980.0)

    def test_gnn_seed_vectors_are_injected_into_nsga_de_population(self):
        tasks = [
            make_task("t1", 100.0, 0, 4, "default"),
            make_task("t2", 80.0, 4, 8, "default"),
            make_task("t3", 60.0, 0, 8, "default"),
        ]
        satellites = [make_satellite("S0", ["default"], windows=2)]
        gnn_model = ASGAT_GNN(num_node_features=10, embedding_dim=8)

        seed_vectors = build_gnn_guided_key_vectors(gnn_model, tasks, satellites)
        self.assertEqual(len(seed_vectors), 4)
        self.assertTrue(all(vector.shape == (len(tasks),) for vector in seed_vectors))
        self.assertTrue(all(0.0 <= value <= 1.0 for vector in seed_vectors for value in vector))

        result = run_profit_first_nsga_de(
            tasks,
            satellites,
            pop_size=12,
            n_gen=0,
            seed=7,
            gnn_model=gnn_model,
        )

        self.assertEqual(result["params"]["gnn_seed_vectors"], 4)

    def test_gnn_cache_loads_when_config_matches(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            cache_path = str(Path(temp_dir) / "gnn_pretrained_asgat.pt")
            task_file = str(Path(temp_dir) / "tasks.csv")
            satellite_file = str(Path(temp_dir) / "satellites.csv")

            first_model = ASGAT_GNN(num_node_features=10)
            second_model = ASGAT_GNN(num_node_features=10)

            with patch("test1.pretrain_gnn_for_nsga_de", return_value=first_model) as pretrain_mock:
                model = load_or_pretrain_gnn_for_nsga_de(
                    cache_path,
                    [task_file],
                    [satellite_file],
                    ["default"],
                    sample_count=1,
                    tasks_per_sample=2,
                    satellites_per_sample=1,
                    epochs_per_sample=1,
                    seed=3,
                    force_retrain=False,
                    log_file=io.StringIO(),
                )

            self.assertIs(model, first_model)
            self.assertTrue(Path(cache_path).exists())
            self.assertEqual(pretrain_mock.call_count, 1)

            with patch("test1.pretrain_gnn_for_nsga_de", return_value=second_model) as pretrain_mock:
                model = load_or_pretrain_gnn_for_nsga_de(
                    cache_path,
                    [task_file],
                    [satellite_file],
                    ["default"],
                    sample_count=1,
                    tasks_per_sample=2,
                    satellites_per_sample=1,
                    epochs_per_sample=1,
                    seed=3,
                    force_retrain=False,
                    log_file=io.StringIO(),
                )

            self.assertIsInstance(model, ASGAT_GNN)
            self.assertEqual(pretrain_mock.call_count, 0)

    def test_schedule_method_summary_preserves_run_order_and_energy_sum(self):
        methods = [
            {
                "method_id": "MethodC",
                "total_profit": 950,
                "total_task_number": 55,
                "energy_available_Wh": [1000, 1000],
                "elapsed_time_sec": 1.23456,
            },
            {
                "method_id": "MethodA",
                "total_profit": 1000,
                "total_task_number": 50,
                "energy_available_Wh": [1200, 1300],
                "elapsed_time_sec": 2.0,
            },
            {
                "method_id": "MethodB",
                "total_profit": 950,
                "total_task_number": 60,
                "energy_available_Wh": [1300, 1500],
                "elapsed_time_sec": 3.0,
            },
            {
                "method_id": "MethodD",
                "total_profit": 950,
                "total_task_number": 60,
                "energy_available_Wh": [2900],
                "elapsed_time_sec": 4.0,
            },
        ]

        sorted_methods = sort_schedule_methods(methods)
        self.assertEqual([method["method_id"] for method in sorted_methods], ["MethodA", "MethodD", "MethodB", "MethodC"])
        self.assertEqual(select_best_schedule_method(methods)["method_id"], "MethodA")
        self.assertIsNone(select_best_schedule_method([]))
        self.assertEqual(calculate_energy_available_sum(methods[0]), 2000.0)

        summary = format_schedule_methods_summary(methods)
        lines = summary.splitlines()
        self.assertEqual(lines[0], "--- 所有调度方法总览 ---")
        self.assertEqual(lines[1], "方法: MethodC")
        self.assertEqual(lines[2], "  总收益: 950.00")
        self.assertEqual(lines[3], "  总任务数: 55")
        self.assertEqual(lines[4], "  剩余总能量: 2000.00 Wh")
        self.assertEqual(lines[5], "  所需时间: 1.2346 秒")
        self.assertEqual(lines[6], "方法: MethodA")
        self.assertEqual(lines[11], "方法: MethodB")
        self.assertEqual(lines[16], "方法: MethodD")
        self.assertEqual(lines[19], "  剩余总能量: 2900.00 Wh")
        self.assertEqual(lines[20], "  所需时间: 4.0000 秒")


if __name__ == "__main__":
    unittest.main()

import dataclasses
from typing import Callable, List, Dict, Sequence, Tuple
import csv
import io
import os
import copy
from bisect import bisect_left

import torch
import torch.nn.functional as F
from torch.nn import Parameter
from torch_geometric.data import Data
from torch_geometric.nn import GCNConv, GATConv, MessagePassing
from torch_geometric.utils import add_self_loops, degree

import numpy as np
from pymoo.core.problem import Problem
from pymoo.algorithms.moo.nsga3 import NSGA3
from pymoo.operators.sampling.rnd import FloatRandomSampling
from pymoo.operators.crossover.sbx import SBX
from pymoo.operators.mutation.pm import PM
from pymoo.optimize import minimize
from pymoo.util.ref_dirs import get_reference_directions
from pymoo.core.population import Population
from pymoo.core.individual import Individual

# 1. --- 数据结构定义 ---
@dataclasses.dataclass
class Task:
    task_id: str
    priority: int
    start_time: int
    end_time: int
    profit: float
    energy: float
    task_type: str
    status: str

@dataclasses.dataclass
class Satellite:
    sat_id: str
    model: str
    energy_available_Wh: float
    status: str
    orbit_height_m: float
    inclination_deg: float
    eccentricity: float
    semi_major_axis: float
    raan: float
    arg_of_perigee: float
    windows_today: int
    completed_tasks: List[Task]
    pending_tasks: List[Task]
    utilization: float
    supported_task_types: List[str]
    total_profit: float = 0.0
    total_task_number: int = 0

# 2. --- 可行性检查工具函数 ---
def check_satellite_status(satellite: Satellite) -> bool:
    return satellite.status == "服务中"

def check_windows_today(satellite: Satellite) -> bool:
    return satellite.windows_today > 0

def check_task_type_support(task: Task, satellite: Satellite) -> bool:
    return task.task_type in satellite.supported_task_types

def check_time_conflict(task: Task, satellite: Satellite) -> bool:
    for existing_task in satellite.completed_tasks + satellite.pending_tasks:
        if max(task.start_time, existing_task.start_time) < min(task.end_time, existing_task.end_time):
            return False
    return True

def check_energy_available(task: Task, satellite: Satellite) -> bool:
    return task.energy <= satellite.energy_available_Wh

def is_feasible(task: Task, satellite: Satellite) -> bool:
    return (
        check_satellite_status(satellite) and
        check_windows_today(satellite) and
        check_task_type_support(task, satellite) and
        check_time_conflict(task, satellite) and
        check_energy_available(task, satellite)
    )

def get_conflicting_tasks(new_task: Task, satellite: Satellite) -> List[Task]:
    conflicts = []
    for existing_task in satellite.pending_tasks:
        if max(new_task.start_time, existing_task.start_time) < min(new_task.end_time, existing_task.end_time):
            conflicts.append(existing_task)
    return conflicts

# 3. --- GNN 和 ASGA 模型定义 ---

class ASGATLayer(MessagePassing):
    """自适应结构图注意力层"""
    def __init__(self, in_channels, out_channels, heads=1, concat=True, dropout=0.6):
        super(ASGATLayer, self).__init__(aggr='add')
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.heads = heads
        self.concat = concat
        self.dropout = dropout

        self.weight = Parameter(torch.Tensor(in_channels, heads * out_channels))
        self.att_weight = Parameter(torch.Tensor(1, heads, 2 * out_channels))

        self.reset_parameters()

    def reset_parameters(self):
        torch.nn.init.xavier_uniform_(self.weight)
        torch.nn.init.xavier_uniform_(self.att_weight)

    def forward(self, x, edge_index):
        x = torch.matmul(x, self.weight)
        return self.propagate(edge_index, x=x)

    def message(self, x_i, x_j, edge_index):
        x_i = x_i.view(-1, self.heads, self.out_channels)
        x_j = x_j.view(-1, self.heads, self.out_channels)
        
        alpha = (torch.cat([x_i, x_j], dim=-1) * self.att_weight).sum(dim=-1)
        alpha = F.leaky_relu(alpha, 0.2)
        alpha = F.softmax(alpha, dim=0) 
        alpha = F.dropout(alpha, p=self.dropout, training=self.training)
        
        return (x_j * alpha.view(-1, self.heads, 1)).view(-1, self.heads * self.out_channels)


class ASGAT_GNN(torch.nn.Module):
    """使用ASGA层的GNN模型"""
    def __init__(self, num_node_features, embedding_dim=64):
        super(ASGAT_GNN, self).__init__()
        self.asga1 = ASGATLayer(num_node_features, 128, heads=1)
        self.asga2 = ASGATLayer(128, embedding_dim, heads=1)

    def forward(self, data):
        x, edge_index = data.x, data.edge_index
        x = F.dropout(x, p=0.6, training=self.training)
        x = F.elu(self.asga1(x, edge_index))
        x = F.dropout(x, p=0.6, training=self.training)
        x = self.asga2(x, edge_index)
        return x

# 4. --- 数据加载和图构建 ---
def get_all_unique_task_types(tasks_file_path: str) -> List[str]:
    unique_task_types = set()
    with open(tasks_file_path, 'r', encoding='utf-8-sig') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            unique_task_types.add(row['task_type'])
    return list(unique_task_types)

def load_satellites(file_path: str, all_task_types: List[str]) -> Dict[str, Satellite]:
    satellites = {}
    with open(file_path, 'r', encoding='utf-8-sig') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            sat_id = row['sat_id']
            satellites[sat_id] = Satellite(
                sat_id=sat_id, model=row['model'],
                energy_available_Wh=float(row['energy_available_Wh']),
                status=row['status'],
                orbit_height_m=float(row['orbit_height_m']),
                inclination_deg=float(row['inclination_deg']),
                eccentricity=float(row['eccentricity']), 
                semi_major_axis=float(row['semi_major_axis']),
                raan=float(row['raan']), 
                arg_of_perigee=float(row['arg_of_perigee']),
                windows_today=int(row['windows_today']), 
                utilization=float(row['utilization']),
                completed_tasks=[], 
                pending_tasks=[], 
                supported_task_types=list(all_task_types)
            )
    return satellites

def build_graph(satellites: Dict[str, Satellite], tasks: List[Task]):
    num_features = 10
    node_features, satellite_indices, task_indices = [], {}, {}
    for idx, (sat_id, sat) in enumerate(satellites.items()):
        features = torch.tensor([sat.energy_available_Wh, sat.windows_today, sat.orbit_height_m, sat.inclination_deg, sat.eccentricity, sat.semi_major_axis, sat.raan, sat.arg_of_perigee, sat.utilization, 0.0], dtype=torch.float)
        node_features.append(features)
        satellite_indices[sat_id] = idx
    task_start_idx = len(satellites)
    for idx, task in enumerate(tasks):
        duration = task.end_time - task.start_time
        features = torch.tensor([task.priority, task.profit, task.energy, duration, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=torch.float)
        node_features.append(features)
        task_indices[task.task_id] = task_start_idx + idx
    x = torch.stack(node_features)
    edge_index_list = []
    for sat_id, sat in satellites.items():
        sat_idx = satellite_indices[sat_id]
        for task in tasks:
            if task.task_type in sat.supported_task_types:
                task_idx = task_indices[task.task_id]
                edge_index_list.extend([[sat_idx, task_idx], [task_idx, sat_idx]])
    if not edge_index_list:
        edge_index = torch.empty((2, 0), dtype=torch.long)
    else:
        edge_index = torch.tensor(edge_index_list, dtype=torch.long).t().contiguous()
    data = Data(x=x, edge_index=edge_index)
    return data, satellite_indices, task_indices

# 5. --- 模型训练与评估 ---
def train_gnn_model(model, data, epochs=50):
    """训练GNN模型"""
    optimizer = torch.optim.Adam(model.parameters(), lr=0.005, weight_decay=5e-4)
    model.train()
    for epoch in range(epochs):
        optimizer.zero_grad()
        out = model(data)
        # 简单的自监督损失：尝试重构邻接矩阵
        adj_pred = torch.sigmoid(torch.matmul(out, out.t()))
        true_adj = torch.zeros(data.num_nodes, data.num_nodes)
        true_adj[data.edge_index[0], data.edge_index[1]] = 1
        loss = F.binary_cross_entropy(adj_pred, true_adj)
        loss.backward()
        optimizer.step()
        if (epoch + 1) % 10 == 0:
            print(f'GNN Training Epoch {epoch+1}/{epochs}, Loss: {loss.item():.4f}')
    model.eval()
    return model

def get_embeddings(model, satellites: Dict[str, Satellite], tasks: List[Task]):
    data, sat_indices, task_indices = build_graph(satellites, tasks)
    with torch.no_grad():
        embeddings = model(data)
    sat_embeddings = {sat_id: embeddings[idx] for sat_id, idx in sat_indices.items()}
    task_embeddings = {task_id: embeddings[idx] for task_id, idx in task_indices.items()}
    return sat_embeddings, task_embeddings

# 6. --- 调度算法 --- 

# (plain_schedule, greedy_schedule, greedy_schedule_agent 函数保持不变, 这里省略)

def try_assign_with_replacement(new_task: Task, satellite: Satellite) -> (bool, List[Task], float):
    if not (check_satellite_status(satellite) and check_windows_today(satellite) and check_task_type_support(new_task, satellite)):
        return False, [], -1.0
    conflicting_tasks = get_conflicting_tasks(new_task, satellite)
    replaced_tasks, energy_after_replacements = [], satellite.energy_available_Wh
    for existing_task in satellite.pending_tasks:
        if existing_task in conflicting_tasks:
            if new_task.priority > existing_task.priority:
                energy_after_replacements += existing_task.energy
                replaced_tasks.append(existing_task)
            else:
                return False, [], -1.0
    if energy_after_replacements < new_task.energy:
        return False, [], -1.0
    return True, replaced_tasks, energy_after_replacements - new_task.energy

def plain_schedule(tasks_file_path: str, all_satellites: Dict[str, Satellite], log_file):
    all_tasks_to_schedule: List[Task] = []
    with open(tasks_file_path, 'r', encoding='utf-8-sig') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            if row['status'] == "调度中":
                all_tasks_to_schedule.append(Task(task_id=row['task_id'], priority=int(row['priority']), start_time=int(row['start_time']), end_time=int(row['end_time']), profit=float(row['profit']), energy=float(row['energy']), task_type=row['task_type'], status=row['status']))
    log_file.write("--- 开始顺序调度 ---\n")
    for task in all_tasks_to_schedule:
        log_file.write(f"任务信息: {task}\n调度结果：\n")
        assigned = False
        for sat_id, satellite in all_satellites.items():
            if is_feasible(task, satellite):
                satellite.pending_tasks.append(task)
                satellite.windows_today -= 1
                satellite.energy_available_Wh -= task.energy
                satellite.total_profit += task.profit
                satellite.total_task_number += 1
                log_file.write(f"任务分配给卫星: {satellite.sat_id}\n卫星当前状态: {satellite}\n")
                assigned = True
                break
        if not assigned:
            log_file.write("未找到合适的卫星\n")

def greedy_schedule(tasks_file_path: str, all_satellites: Dict[str, Satellite], log_file):
    all_tasks_to_schedule: List[Task] = []
    with open(tasks_file_path, 'r', encoding='utf-8-sig') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            if row['status'] == "调度中":
                all_tasks_to_schedule.append(Task(task_id=row['task_id'], priority=int(row['priority']), start_time=int(row['start_time']), end_time=int(row['end_time']), profit=float(row['profit']), energy=float(row['energy']), task_type=row['task_type'], status=row['status']))
    all_tasks_to_schedule.sort(key=lambda t: (t.priority, t.profit), reverse=True)
    log_file.write("--- 开始贪婪调度 ---\n")
    for task in all_tasks_to_schedule:
        log_file.write(f"任务信息: {task}\n调度结果：\n")
        best_satellite_id, min_replaced_tasks, best_replaced_tasks_for_assignment = None, float('inf'), []
        for sat_id, satellite in all_satellites.items():
            can_assign, current_replaced_tasks, _ = try_assign_with_replacement(task, satellite)
            if can_assign and len(current_replaced_tasks) < min_replaced_tasks:
                min_replaced_tasks = len(current_replaced_tasks)
                best_satellite_id = sat_id
                best_replaced_tasks_for_assignment = current_replaced_tasks
        if best_satellite_id:
            original_satellite = all_satellites[best_satellite_id]
            for replaced_task in best_replaced_tasks_for_assignment:
                original_satellite.energy_available_Wh += replaced_task.energy
                original_satellite.total_profit -= replaced_task.profit
                original_satellite.total_task_number -= 1
                original_satellite.pending_tasks.remove(replaced_task)
            original_satellite.pending_tasks.append(task)
            original_satellite.windows_today -= 1
            original_satellite.energy_available_Wh -= task.energy
            original_satellite.total_profit += task.profit
            original_satellite.total_task_number += 1
            log_file.write(f"任务分配给卫星: {original_satellite.sat_id}\n卫星当前状态: {original_satellite}\n")
        else:
            log_file.write("未找到合适的卫星\n")
    log_file.write("--- 贪婪调度结束 ---\n")

def greedy_schedule_agent(tasks_file_path: str, all_satellites: Dict[str, Satellite], log_file):
    all_tasks_to_schedule: List[Task] = []
    with open(tasks_file_path, 'r', encoding='utf-8-sig') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            if row['status'] == "调度中":
                all_tasks_to_schedule.append(Task(task_id=row['task_id'], priority=int(row['priority']), start_time=int(row['start_time']), end_time=int(row['end_time']), profit=float(row['profit']), energy=float(row['energy']), task_type=row['task_type'], status=row['status']))
    all_tasks_to_schedule.sort(key=lambda t: (t.priority, t.profit), reverse=True)
    log_file.write("--- 开始智能贪婪调度 ---\n")
    for task in all_tasks_to_schedule:
        log_file.write(f"任务信息: {task}\n调度结果：\n")
        best_satellite_id, min_replaced_tasks, max_net_profit_gain = None, float('inf'), -float('inf')
        for sat_id, satellite in all_satellites.items():
            can_assign, replaced_tasks, _ = try_assign_with_replacement(task, satellite)
            if can_assign:
                current_net_profit_gain = task.profit - sum(t.profit for t in replaced_tasks)
                num_replaced = len(replaced_tasks)
                if num_replaced < min_replaced_tasks or (num_replaced == min_replaced_tasks and current_net_profit_gain > max_net_profit_gain):
                    min_replaced_tasks = num_replaced
                    max_net_profit_gain = current_net_profit_gain
                    best_satellite_id = sat_id
        if best_satellite_id:
            original_satellite = all_satellites[best_satellite_id]
            conflicting_tasks = get_conflicting_tasks(task, original_satellite)
            for ct in conflicting_tasks:
                if task.priority > ct.priority:
                    original_satellite.energy_available_Wh += ct.energy
                    original_satellite.total_profit -= ct.profit
                    original_satellite.total_task_number -= 1
                    original_satellite.pending_tasks.remove(ct)
            original_satellite.pending_tasks.append(task)
            original_satellite.windows_today -= 1
            original_satellite.energy_available_Wh -= task.energy
            original_satellite.total_profit += task.profit
            original_satellite.total_task_number += 1
            log_file.write(f"任务分配给卫星: {original_satellite.sat_id}\n卫星当前状态: {original_satellite}\n")
        else:
            log_file.write("未找到合适的卫星\n")
    log_file.write("--- 智能贪婪调度结束 ---\n")

class SatelliteTaskSchedulingProblem(Problem):
    def __init__(self, tasks, satellites, task_embeddings, sat_embeddings):
        self.tasks, self.satellites, self.task_embeddings, self.sat_embeddings = tasks, list(satellites.values()), task_embeddings, sat_embeddings
        self.num_tasks, self.num_satellites = len(tasks), len(self.satellites)
        super().__init__(n_var=self.num_tasks, n_obj=2, n_constr=0, xl=0, xu=self.num_satellites - 1, type_var=int)

    def _evaluate(self, X, out, *args, **kwargs):
        F = np.zeros((X.shape[0], self.n_obj))
        for i, x in enumerate(X):
            total_profit, total_tasks, _ = evaluate_assignment(self.tasks, self.satellites, x)
            F[i, 0], F[i, 1] = -total_profit, -total_tasks
        out["F"] = F


def evaluate_assignment(
    tasks: Sequence[Task],
    satellites: Sequence[Satellite],
    assignment: Sequence[int],
) -> Tuple[float, int, List[Tuple[int, Task]]]:
    """Evaluate one assignment using lexicographic scheduling metrics.

    The returned values count only newly accepted tasks. Existing satellite
    pending/completed tasks are treated as occupied resources for conflict
    checks, but are not counted again in the candidate score.
    """
    total_profit, total_tasks = 0.0, 0
    sat_energy = [sat.energy_available_Wh for sat in satellites]
    sat_windows = [sat.windows_today for sat in satellites]
    sat_assigned_tasks = [
        list(sat.completed_tasks) + list(sat.pending_tasks)
        for sat in satellites
    ]
    accepted: List[Tuple[int, Task]] = []

    for task_idx, task in enumerate(tasks):
        if task_idx >= len(assignment):
            break
        sat_idx = int(assignment[task_idx])
        if sat_idx < 0 or sat_idx >= len(satellites):
            continue

        satellite = satellites[sat_idx]
        if satellite.status != "服务中":
            continue
        if sat_windows[sat_idx] <= 0:
            continue
        if task.task_type not in satellite.supported_task_types:
            continue
        if sat_energy[sat_idx] < task.energy:
            continue

        has_conflict = any(
            max(task.start_time, existing_task.start_time) < min(task.end_time, existing_task.end_time)
            for existing_task in sat_assigned_tasks[sat_idx]
        )
        if has_conflict:
            continue

        total_profit += task.profit
        total_tasks += 1
        sat_energy[sat_idx] -= task.energy
        sat_windows[sat_idx] -= 1
        sat_assigned_tasks[sat_idx].append(task)
        accepted.append((sat_idx, task))

    return total_profit, total_tasks, accepted


def select_lexicographic_best_assignment(
    candidate_assignments: Sequence[Sequence[int]],
    tasks: Sequence[Task],
    satellites: Sequence[Satellite],
    profit_tolerance: float = 1e-9,
) -> Tuple[np.ndarray, float, int]:
    """Select the best candidate by profit first, then task count.

    NSGA-III supplies a Pareto set. This selector makes the final decision
    deterministic and strict: maximize total_profit; among equal-profit
    candidates, maximize total_task_number.
    """
    best_assignment = None
    best_profit = -float("inf")
    best_task_count = -1
    best_remaining_energy = -float("inf")

    for assignment in candidate_assignments:
        total_profit, total_tasks, accepted = evaluate_assignment(tasks, satellites, assignment)
        remaining_energy = (
            sum(satellite.energy_available_Wh for satellite in satellites)
            - sum(task.energy for _, task in accepted)
        )
        profit_is_better = total_profit > best_profit + profit_tolerance
        profit_is_equal = abs(total_profit - best_profit) <= profit_tolerance
        task_count_is_better = total_tasks > best_task_count
        task_count_is_equal = total_tasks == best_task_count
        energy_is_better = remaining_energy > best_remaining_energy + profit_tolerance

        if (
            profit_is_better
            or (
                profit_is_equal
                and (
                    task_count_is_better
                    or (task_count_is_equal and energy_is_better)
                )
            )
        ):
            best_assignment = np.asarray(assignment, dtype=int)
            best_profit = total_profit
            best_task_count = total_tasks
            best_remaining_energy = remaining_energy

    if best_assignment is None:
        return np.array([], dtype=int), 0.0, 0

    return best_assignment, best_profit, best_task_count


def apply_assignment_to_satellites(
    tasks: Sequence[Task],
    satellites: Sequence[Satellite],
    assignment: Sequence[int],
    log_file=None,
) -> Tuple[float, int]:
    """Apply one assignment with the same feasibility rules used in evaluation."""
    total_profit, total_tasks, accepted = evaluate_assignment(tasks, satellites, assignment)
    for sat_idx, task in accepted:
        satellite = satellites[sat_idx]
        satellite.pending_tasks.append(task)
        satellite.windows_today -= 1
        satellite.energy_available_Wh -= task.energy
        satellite.total_profit += task.profit
        satellite.total_task_number += 1
        if log_file is not None:
            log_file.write(f"任务 {task.task_id} 分配给卫星 {satellite.sat_id}\n")

    return total_profit, total_tasks


def _task_duration(task: Task) -> int:
    return max(task.end_time - task.start_time, 1)


def _can_insert_interval(starts: List[int], ends: List[int], start: int, end: int) -> bool:
    pos = bisect_left(starts, start)
    if pos > 0 and ends[pos - 1] > start:
        return False
    if pos < len(starts) and starts[pos] < end:
        return False
    return True


def _insert_interval(starts: List[int], ends: List[int], start: int, end: int) -> None:
    pos = bisect_left(starts, start)
    starts.insert(pos, start)
    ends.insert(pos, end)


def decode_task_order(
    tasks: Sequence[Task],
    satellites: Sequence[Satellite],
    order: Sequence[int],
) -> Tuple[float, int, float, List[Tuple[int, Task]]]:
    """Decode a task order into a feasible schedule using profit-preserving best fit.

    The random-key optimizer searches only over task order. This decoder is
    deterministic and keeps every returned schedule feasible by checking status,
    windows, task type, energy, and time conflicts before each insertion.
    """
    sat_energy = [sat.energy_available_Wh for sat in satellites]
    sat_windows = [sat.windows_today for sat in satellites]
    sat_starts: List[List[int]] = []
    sat_ends: List[List[int]] = []

    for sat in satellites:
        intervals = sorted(
            (task.start_time, task.end_time)
            for task in list(sat.completed_tasks) + list(sat.pending_tasks)
        )
        sat_starts.append([start for start, _ in intervals])
        sat_ends.append([end for _, end in intervals])

    total_profit, total_tasks = 0.0, 0
    accepted: List[Tuple[int, Task]] = []

    for task_idx in order:
        if task_idx < 0 or task_idx >= len(tasks):
            continue
        task = tasks[int(task_idx)]
        best_sat_idx = None
        best_score = None

        for sat_idx, satellite in enumerate(satellites):
            if satellite.status != "服务中":
                continue
            if sat_windows[sat_idx] <= 0:
                continue
            if task.task_type not in satellite.supported_task_types:
                continue
            if sat_energy[sat_idx] < task.energy:
                continue
            if not _can_insert_interval(
                sat_starts[sat_idx],
                sat_ends[sat_idx],
                task.start_time,
                task.end_time,
            ):
                continue

            energy_after = sat_energy[sat_idx] - task.energy
            windows_after = sat_windows[sat_idx] - 1
            score = (energy_after, windows_after, satellite.utilization, sat_idx)
            if best_score is None or score < best_score:
                best_score = score
                best_sat_idx = sat_idx

        if best_sat_idx is None:
            continue

        sat_energy[best_sat_idx] -= task.energy
        sat_windows[best_sat_idx] -= 1
        _insert_interval(
            sat_starts[best_sat_idx],
            sat_ends[best_sat_idx],
            task.start_time,
            task.end_time,
        )
        total_profit += task.profit
        total_tasks += 1
        accepted.append((best_sat_idx, task))

    return total_profit, total_tasks, float(sum(sat_energy)), accepted


def apply_decoded_schedule_to_satellites(
    satellites: Sequence[Satellite],
    accepted: Sequence[Tuple[int, Task]],
    log_file=None,
) -> None:
    for sat_idx, task in accepted:
        satellite = satellites[sat_idx]
        satellite.pending_tasks.append(task)
        satellite.windows_today -= 1
        satellite.energy_available_Wh -= task.energy
        satellite.total_profit += task.profit
        satellite.total_task_number += 1
        if log_file is not None:
            log_file.write(f"任务 {task.task_id} 分配给卫星 {satellite.sat_id}\n")


def _keys_from_task_score(
    tasks: Sequence[Task],
    score_fn: Callable[[Task], Tuple[float, ...]],
) -> np.ndarray:
    n_tasks = len(tasks)
    keys = np.zeros(n_tasks, dtype=np.float64)
    ranked_task_indices = sorted(
        range(n_tasks),
        key=lambda idx: (score_fn(tasks[idx]), -idx),
        reverse=True,
    )
    for rank, task_idx in enumerate(ranked_task_indices):
        keys[task_idx] = 1.0 - rank / max(n_tasks, 1)
    return keys


def _seed_random_key_population(
    tasks: Sequence[Task],
    pop_size: int,
    rng: np.random.Generator,
) -> np.ndarray:
    heuristic_scores: List[Callable[[Task], Tuple[float, ...]]] = [
        lambda task: (task.priority, task.profit),
        lambda task: (task.profit,),
        lambda task: (task.profit / _task_duration(task), task.profit),
        lambda task: (task.profit / max(task.energy, 1e-9), task.profit),
        lambda task: (
            task.profit / max(task.energy * _task_duration(task), 1e-9),
            task.profit,
        ),
        lambda task: (task.priority, task.profit / _task_duration(task), task.profit),
        lambda task: (-_task_duration(task), task.profit),
    ]

    base_vectors = [_keys_from_task_score(tasks, score_fn) for score_fn in heuristic_scores]
    population = []
    for keys in base_vectors:
        population.append(keys)
        if len(population) >= pop_size:
            break

    jitter_scale = 0.03
    while len(population) < min(pop_size, len(base_vectors) * 4):
        base = base_vectors[len(population) % len(base_vectors)]
        jittered = np.clip(base + rng.normal(0.0, jitter_scale, size=len(tasks)), 0.0, 1.0)
        population.append(jittered)

    while len(population) < pop_size:
        population.append(rng.random(len(tasks)))

    return np.vstack(population[:pop_size]).astype(np.float64)


def _evaluate_random_keys(
    keys: np.ndarray,
    tasks: Sequence[Task],
    satellites: Sequence[Satellite],
) -> Tuple[float, int, float, List[Tuple[int, Task]]]:
    order = np.argsort(-keys).tolist()
    return decode_task_order(tasks, satellites, order)


def _dominates_max(objective_a: Tuple[float, int, float], objective_b: Tuple[float, int, float]) -> bool:
    return (
        all(a >= b for a, b in zip(objective_a, objective_b))
        and any(a > b for a, b in zip(objective_a, objective_b))
    )


def _fast_non_dominated_sort_max(objectives: Sequence[Tuple[float, int, float]]) -> List[List[int]]:
    n_items = len(objectives)
    dominated_count = [0] * n_items
    dominates = [[] for _ in range(n_items)]
    fronts = [[]]

    for i in range(n_items):
        for j in range(i + 1, n_items):
            if _dominates_max(objectives[i], objectives[j]):
                dominates[i].append(j)
                dominated_count[j] += 1
            elif _dominates_max(objectives[j], objectives[i]):
                dominates[j].append(i)
                dominated_count[i] += 1
        if dominated_count[i] == 0:
            fronts[0].append(i)

    front_idx = 0
    while front_idx < len(fronts) and fronts[front_idx]:
        next_front = []
        for i in fronts[front_idx]:
            for j in dominates[i]:
                dominated_count[j] -= 1
                if dominated_count[j] == 0:
                    next_front.append(j)
        fronts.append(next_front)
        front_idx += 1

    return fronts[:-1]


def _crowding_distance_max(front: Sequence[int], objectives: Sequence[Tuple[float, int, float]]) -> List[float]:
    front_size = len(front)
    if front_size <= 2:
        return [float("inf")] * front_size

    distances = [0.0] * front_size
    for obj_idx in range(len(objectives[0])):
        ranked_positions = sorted(range(front_size), key=lambda pos: objectives[front[pos]][obj_idx])
        distances[ranked_positions[0]] = float("inf")
        distances[ranked_positions[-1]] = float("inf")
        min_value = objectives[front[ranked_positions[0]]][obj_idx]
        max_value = objectives[front[ranked_positions[-1]]][obj_idx]
        value_range = max_value - min_value
        if value_range == 0:
            continue
        for pos in range(1, front_size - 1):
            prev_value = objectives[front[ranked_positions[pos - 1]]][obj_idx]
            next_value = objectives[front[ranked_positions[pos + 1]]][obj_idx]
            distances[ranked_positions[pos]] += (next_value - prev_value) / value_range

    return distances


def _profit_first_survivors(
    profits: np.ndarray,
    task_counts: np.ndarray,
    remaining_energy_sums: np.ndarray,
    pop_size: int,
    elite_fraction: float = 0.35,
) -> List[int]:
    objectives = list(zip(
        profits.tolist(),
        task_counts.astype(int).tolist(),
        remaining_energy_sums.tolist(),
    ))
    elite_count = max(1, min(pop_size, int(pop_size * elite_fraction)))
    lexicographic_elites = sorted(
        range(len(objectives)),
        key=lambda idx: (objectives[idx][0], objectives[idx][1], objectives[idx][2]),
        reverse=True,
    )[:elite_count]

    survivors = []
    survivor_set = set()
    for idx in lexicographic_elites:
        survivors.append(idx)
        survivor_set.add(idx)

    for front in _fast_non_dominated_sort_max(objectives):
        remaining_front = [idx for idx in front if idx not in survivor_set]
        if not remaining_front:
            continue
        if len(survivors) + len(remaining_front) <= pop_size:
            survivors.extend(remaining_front)
            survivor_set.update(remaining_front)
            continue

        needed = pop_size - len(survivors)
        distances = _crowding_distance_max(remaining_front, objectives)
        ranked = sorted(
            zip(distances, remaining_front),
            key=lambda item: (
                item[0],
                objectives[item[1]][0],
                objectives[item[1]][1],
                objectives[item[1]][2],
            ),
            reverse=True,
        )
        chosen = [idx for _, idx in ranked[:needed]]
        survivors.extend(chosen)
        survivor_set.update(chosen)
        break

    if len(survivors) < pop_size:
        for idx in sorted(
            range(len(objectives)),
            key=lambda item_idx: (
                objectives[item_idx][0],
                objectives[item_idx][1],
                objectives[item_idx][2],
            ),
            reverse=True,
        ):
            if idx not in survivor_set:
                survivors.append(idx)
                if len(survivors) == pop_size:
                    break

    return survivors[:pop_size]


def run_profit_first_nsga_de(
    tasks: Sequence[Task],
    satellites: Sequence[Satellite],
    pop_size: int = 80,
    n_gen: int = 100,
    differential_weight: float = 0.6,
    crossover_rate: float = 0.85,
    seed: int = 42,
) -> Dict[str, object]:
    """Run a profit-first NSGA-DE search over random-key task orders."""
    if not tasks or not satellites:
        remaining_energy = sum(satellite.energy_available_Wh for satellite in satellites)
        return {
            "total_profit": 0.0,
            "total_task_number": 0,
            "energy_available_Wh_sum": float(remaining_energy),
            "accepted": [],
            "convergence": [],
            "params": {
                "pop_size": 0,
                "n_gen": 0,
                "F": differential_weight,
                "CR": crossover_rate,
                "seed": seed,
            },
        }

    n_tasks = len(tasks)
    pop_size = max(8, int(pop_size))
    n_gen = max(0, int(n_gen))
    rng = np.random.default_rng(seed)

    population = _seed_random_key_population(tasks, pop_size, rng)
    profits = np.zeros(pop_size, dtype=np.float64)
    task_counts = np.zeros(pop_size, dtype=np.int64)
    remaining_energy_sums = np.zeros(pop_size, dtype=np.float64)
    accepted_schedules: List[List[Tuple[int, Task]]] = [[] for _ in range(pop_size)]

    for idx in range(pop_size):
        (
            profits[idx],
            task_counts[idx],
            remaining_energy_sums[idx],
            accepted_schedules[idx],
        ) = _evaluate_random_keys(
            population[idx],
            tasks,
            satellites,
        )

    convergence = [float(np.max(profits))]

    for _ in range(n_gen):
        trials = np.empty_like(population)
        index_pool = np.arange(pop_size)

        for idx in range(pop_size):
            candidates = index_pool[index_pool != idx]
            if len(candidates) >= 3:
                r1, r2, r3 = rng.choice(candidates, 3, replace=False)
                mutant = population[r1] + differential_weight * (population[r2] - population[r3])
                mutant = np.clip(mutant, 0.0, 1.0)
            else:
                mutant = rng.random(n_tasks)

            crossover_mask = rng.random(n_tasks) < crossover_rate
            if not crossover_mask.any():
                crossover_mask[rng.integers(n_tasks)] = True
            trials[idx] = np.where(crossover_mask, mutant, population[idx])

        trial_profits = np.zeros(pop_size, dtype=np.float64)
        trial_task_counts = np.zeros(pop_size, dtype=np.int64)
        trial_remaining_energy_sums = np.zeros(pop_size, dtype=np.float64)
        trial_accepted: List[List[Tuple[int, Task]]] = [[] for _ in range(pop_size)]
        for idx in range(pop_size):
            (
                trial_profits[idx],
                trial_task_counts[idx],
                trial_remaining_energy_sums[idx],
                trial_accepted[idx],
            ) = _evaluate_random_keys(
                trials[idx],
                tasks,
                satellites,
            )

        combined_population = np.vstack([population, trials])
        combined_profits = np.concatenate([profits, trial_profits])
        combined_task_counts = np.concatenate([task_counts, trial_task_counts])
        combined_remaining_energy_sums = np.concatenate([
            remaining_energy_sums,
            trial_remaining_energy_sums,
        ])
        combined_accepted = accepted_schedules + trial_accepted

        survivors = _profit_first_survivors(
            combined_profits,
            combined_task_counts,
            combined_remaining_energy_sums,
            pop_size,
        )
        population = combined_population[survivors]
        profits = combined_profits[survivors]
        task_counts = combined_task_counts[survivors]
        remaining_energy_sums = combined_remaining_energy_sums[survivors]
        accepted_schedules = [combined_accepted[idx] for idx in survivors]
        convergence.append(float(np.max(profits)))

    best_idx = max(
        range(pop_size),
        key=lambda idx: (profits[idx], int(task_counts[idx]), remaining_energy_sums[idx]),
    )
    return {
        "total_profit": float(profits[best_idx]),
        "total_task_number": int(task_counts[best_idx]),
        "energy_available_Wh_sum": float(remaining_energy_sums[best_idx]),
        "accepted": accepted_schedules[best_idx],
        "convergence": convergence,
        "params": {
            "pop_size": pop_size,
            "n_gen": n_gen,
            "F": differential_weight,
            "CR": crossover_rate,
            "seed": seed,
        },
    }

def gnn_based_sampling(problem, n_samples):
    X = np.zeros((n_samples, problem.n_var), dtype=int)
    for j, task in enumerate(problem.tasks):
        task_emb = problem.task_embeddings[task.task_id]
        scores = [torch.cosine_similarity(task_emb.unsqueeze(0), problem.sat_embeddings[sat.sat_id].unsqueeze(0)).item() for sat in problem.satellites]
        probs = np.exp(scores) / np.sum(np.exp(scores))
        for i in range(n_samples):
            X[i, j] = np.random.choice(len(problem.satellites), p=probs)
    return Population.new(X=X)

def multi_objective_schedule(
    tasks_file_path: str,
    all_satellites: Dict[str, Satellite],
    log_file,
    gnn_model=None,
    pop_size: int = 80,
    n_gen: int = 100,
    seed: int = 42,
):
    """Profit-first NSGA-DE scheduler.

    `gnn_model` is kept for backwards-compatible callers. The optimizer now
    follows the random-key NSGA-DE design from nsga_de.py and uses total profit
    as the dominant objective throughout selection and final application.
    """
    all_tasks = []
    with open(tasks_file_path, 'r', encoding='utf-8-sig') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            if row['status'] == "调度中":
                all_tasks.append(Task(task_id=row['task_id'], priority=int(row['priority']), start_time=int(row['start_time']), end_time=int(row['end_time']), profit=float(row['profit']), energy=float(row['energy']), task_type=row['task_type'], status=row['status']))

    if not all_tasks:
        log_file.write("没有状态为“调度中”的任务\n")
        log_file.write("--- 多目标调度结束 ---\n")
        return
    if not all_satellites:
        log_file.write("没有可用卫星\n")
        log_file.write("--- 多目标调度结束 ---\n")
        return

    baseline_satellites = copy.deepcopy(all_satellites)
    greedy_schedule_agent(tasks_file_path, baseline_satellites, io.StringIO())
    baseline_profit = sum(satellite.total_profit for satellite in baseline_satellites.values())
    baseline_task_count = sum(satellite.total_task_number for satellite in baseline_satellites.values())
    baseline_energy_sum = sum(satellite.energy_available_Wh for satellite in baseline_satellites.values())

    satellite_list = list(all_satellites.values())
    result = run_profit_first_nsga_de(
        all_tasks,
        satellite_list,
        pop_size=pop_size,
        n_gen=n_gen,
        seed=seed,
    )

    if result["total_profit"] <= baseline_profit:
        retry_result = run_profit_first_nsga_de(
            all_tasks,
            satellite_list,
            pop_size=max(pop_size, 120),
            n_gen=max(n_gen, 160),
            seed=seed + 1,
        )
        if (
            retry_result["total_profit"] > result["total_profit"]
            or (
                abs(retry_result["total_profit"] - result["total_profit"]) <= 1e-9
                and (
                    retry_result["total_task_number"] > result["total_task_number"]
                    or (
                        retry_result["total_task_number"] == result["total_task_number"]
                        and retry_result["energy_available_Wh_sum"] > result["energy_available_Wh_sum"]
                    )
                )
            )
        ):
            result = retry_result

    log_file.write(
        "NSGA-DE 收益优先调度: "
        f"total_profit={result['total_profit']:.2f}, "
        f"total_task_number={result['total_task_number']}, "
        f"energy_available_Wh_sum={result['energy_available_Wh_sum']:.2f}\n"
    )
    log_file.write(
        "greedy_schedule_agent 基线: "
        f"total_profit={baseline_profit:.2f}, "
        f"total_task_number={baseline_task_count}, "
        f"energy_available_Wh_sum={baseline_energy_sum:.2f}\n"
    )
    improvement = result["total_profit"] - baseline_profit
    log_file.write(f"相对智能贪婪收益提升: {improvement:.2f}\n")
    if improvement <= 0:
        log_file.write("警告: 当前搜索未找到高于 greedy_schedule_agent 的方案\n")

    apply_decoded_schedule_to_satellites(satellite_list, result["accepted"], log_file)
    log_file.write("--- 多目标调度结束 ---\n")

# 7. --- 统计与输出 ---
def print_satellite_statistics(all_satellites: Dict[str, Satellite], schedule_name: str, log_file):
    console_output = f"\n--- {schedule_name} 统计信息 ---"
    log_file.write(console_output + "\n")
    print(console_output)
    total_profit_sum, total_task_number_sum, total_energy_available_sum = 0.0, 0, 0.0
    for sat_id, satellite in all_satellites.items():
        console_output_sat = (
            f"卫星 {sat_id}:\n"
            f"  总收益: {satellite.total_profit:.2f}\n"
            f"  总任务数: {satellite.total_task_number}\n"
            f"  剩余能量: {satellite.energy_available_Wh:.2f} Wh"
        )
        log_file.write(console_output_sat + "\n")
        print(console_output_sat)
        total_profit_sum += satellite.total_profit
        total_task_number_sum += satellite.total_task_number
        total_energy_available_sum += satellite.energy_available_Wh
    console_output_total = (
        f"\n所有卫星总计:\n"
        f"  总收益: {total_profit_sum:.2f}\n"
        f"  总任务数: {total_task_number_sum}\n"
        f"  剩余总能量: {total_energy_available_sum:.2f} Wh"
    )
    log_file.write(console_output_total + "\n")
    print(console_output_total)
    console_output_end = f"--- {schedule_name} 统计信息结束 ---\n"
    log_file.write(console_output_end + "\n")
    print(console_output_end)


def calculate_energy_available_sum(schedule_method) -> float:
    """Return the total remaining energy for one scheduling method."""
    if isinstance(schedule_method, dict):
        energy_values = schedule_method.get("energy_available_Wh", [])
    else:
        energy_values = getattr(schedule_method, "energy_available_Wh", [])

    if energy_values is None:
        return 0.0
    if isinstance(energy_values, (int, float, np.number)):
        return float(energy_values)

    total_energy = 0.0
    for value in energy_values:
        if value is None:
            continue
        total_energy += float(value)
    return total_energy


def sort_schedule_methods(schedule_methods: Sequence) -> List:
    """Sort methods by profit, task count, then remaining energy, all descending."""
    def sort_key(method):
        if isinstance(method, dict):
            total_profit = method.get("total_profit", 0.0)
            total_task_number = method.get("total_task_number", method.get("total_tasks", 0))
        else:
            total_profit = getattr(method, "total_profit", 0.0)
            total_task_number = getattr(method, "total_task_number", getattr(method, "total_tasks", 0))
        return (
            float(total_profit),
            float(total_task_number),
            calculate_energy_available_sum(method),
        )

    return sorted(schedule_methods, key=sort_key, reverse=True)


def select_best_schedule_method(schedule_methods: Sequence):
    """Return the best method by profit, then task count, then energy sum."""
    sorted_methods = sort_schedule_methods(schedule_methods)
    if not sorted_methods:
        return None
    return sorted_methods[0]


def build_schedule_method_result(method_id: str, satellites: Dict[str, Satellite]) -> Dict[str, object]:
    return {
        "method_id": method_id,
        "total_profit": sum(satellite.total_profit for satellite in satellites.values()),
        "total_task_number": sum(satellite.total_task_number for satellite in satellites.values()),
        "energy_available_Wh": [
            satellite.energy_available_Wh
            for satellite in satellites.values()
        ],
    }


def format_schedule_methods_summary(schedule_methods: Sequence) -> str:
    lines = ["--- 所有调度方法总览 ---"]
    for method in schedule_methods:
        if isinstance(method, dict):
            method_id = method.get("method_id", "")
            total_profit = method.get("total_profit", 0.0)
            total_task_number = method.get("total_task_number", method.get("total_tasks", 0))
        else:
            method_id = getattr(method, "method_id", "")
            total_profit = getattr(method, "total_profit", 0.0)
            total_task_number = getattr(method, "total_task_number", getattr(method, "total_tasks", 0))

        lines.append(
            f"方法: {method_id}\n"
            f"  总收益: {float(total_profit):.2f}\n"
            f"  总任务数: {float(total_task_number):g}\n"
            f"  剩余总能量: {calculate_energy_available_sum(method):.2f} Wh"
        )
    return "\n".join(lines)

# 8. --- 主执行入口 ---
if __name__ == "__main__":
    base_path = "C:\\Users\\asus\\Desktop\\求真杯"
    output_dir = os.path.join(base_path, "output_logs")
    os.makedirs(output_dir, exist_ok=True)
    satellites_file = os.path.join(base_path, "satellite_sample_143.csv")
    tasks_input_file = os.path.join(base_path, "task_sample_5000.csv")

    all_task_types_from_input = get_all_unique_task_types(tasks_input_file)
    initial_satellites = load_satellites(satellites_file, all_task_types_from_input)
    
    # 加载所有任务用于GNN
    all_tasks_for_gnn: List[Task] = []
    with open(tasks_input_file, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['status'] == "调度中":
                all_tasks_for_gnn.append(Task(task_id=row['task_id'], priority=int(row['priority']), start_time=int(row['start_time']), end_time=int(row['end_time']), profit=float(row['profit']), energy=float(row['energy']), task_type=row['task_type'], status=row['status']))

    # 多目标调度已改为收益优先 NSGA-DE 随机键解码器，不再依赖 GNN 训练。
    trained_asgat_model = None

    results = []
    schedulers = {
        "plain_schedule": plain_schedule,
        "greedy_schedule": greedy_schedule,
        "greedy_schedule_agent": greedy_schedule_agent,
    }

    for name, func in schedulers.items():
        satellites_copy = copy.deepcopy(initial_satellites)
        log_path = os.path.join(output_dir, f"{name}_log.txt")
        with open(log_path, 'w', encoding='utf-8') as log_f:
            func(tasks_input_file, satellites_copy, log_f)
            print_satellite_statistics(satellites_copy, name.replace('_', ' ').title(), log_f)
        print(f"{name.replace('_', ' ').title()} 调度结果已写入: {log_path}")
        results.append(build_schedule_method_result(name, satellites_copy))
    
    # 多目标调度
    multi_obj_satellites = copy.deepcopy(initial_satellites)
    multi_obj_log_file_path = os.path.join(output_dir, "multi_objective_schedule_log.txt")
    with open(multi_obj_log_file_path, 'w', encoding='utf-8') as log_f:
        multi_objective_schedule(tasks_input_file, multi_obj_satellites, log_f, trained_asgat_model)
        print_satellite_statistics(multi_obj_satellites, "Multi-Objective Schedule", log_f)
    print(f"Multi-Objective Schedule 调度结果已写入: {multi_obj_log_file_path}")
    results.append(build_schedule_method_result("multi_objective_schedule", multi_obj_satellites))

    # --- 最终总结 ---
    summary_log_file_path = os.path.join(output_dir, "summary_log.txt")
    with open(summary_log_file_path, 'w', encoding='utf-8') as summary_log_f:
        summary_text = format_schedule_methods_summary(results)
        summary_log_f.write(summary_text + "\n")
        print(summary_text)
        summary_footer = "------------------------"
        summary_log_f.write(summary_footer + "\n")
        print(summary_footer)
    print(f"最终总结已写入: {summary_log_file_path}")
